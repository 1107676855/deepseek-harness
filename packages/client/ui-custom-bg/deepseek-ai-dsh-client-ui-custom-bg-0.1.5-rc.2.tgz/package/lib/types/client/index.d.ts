/** User background theme: wallpaper stylesheet plus translucent surface tokens. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
/** Required service: the theme runtime that folds token override layers. */
export declare const inject: string[];
/**
 * Stack the surface overrides and mount the wallpaper stylesheet for this
 * plugin's lifetime.
 * @param ctx - Client cordis context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map